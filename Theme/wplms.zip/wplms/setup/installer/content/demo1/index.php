<?php

// This is the folder the setup wizard places content into when it exports.
// The setup wizard will read the json files from this folder when importing.