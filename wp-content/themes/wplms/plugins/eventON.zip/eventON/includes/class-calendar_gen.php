<?php
/**
 * Calendar Data Generator
 */

class EVO_Cal_Gen{
	public function __construct(){

	}
}