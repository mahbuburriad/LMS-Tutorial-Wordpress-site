=====================================
 How to install EventON Addons
=====================================
EventON addons can be installed just like a normal plugin in WordPress.

Step 1:
Go to WP Admin > Plugins > Add New

Step 2: 
Select "Upload" and choose the zip file of the addon (ONLY) 

Step 3:
Click Install Now and follow the screen to activate.

You can also install this EventON Extension by upzipping the file content and uploading the content to "wp-content/plugins/" directory. 

=====================================
 Other Online Resources
=====================================
How to download addon updates: http://www.myeventon.com/documentation/can-download-addon-updates/
Online documentation library: http://www.myeventon.com/documentation/
